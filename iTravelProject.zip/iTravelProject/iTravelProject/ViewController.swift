//
//  ViewController.swift
//  iTravelProject
//
//  Created by Ankush Dewang on 2/27/19.
//  Copyright © 2019 Ankush Dewang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

